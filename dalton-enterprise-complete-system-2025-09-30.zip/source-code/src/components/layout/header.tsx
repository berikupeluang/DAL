"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { useRouter } from "next/navigation"
import { 
  Bell, 
  Settings,
  Globe
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

interface HeaderProps {
  className?: string
}

export function Header({ className }: HeaderProps) {
  const router = useRouter()

  const handleSettingsClick = () => {
    router.push("/settings")
  }

  return (
    <header className={`sticky top-0 z-40 w-full border-b bg-background enhanced-visibility ${className || ""}`}>
      <div className="container h-16 px-2 sm:px-4">
        <div className="flex items-center justify-end h-full">
          <nav className="flex items-center space-x-3 sm:space-x-4">
            {/* Language selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-10 w-10 sm:h-11 sm:w-11 btn-ghost-better">
                  <Globe className="h-5 w-5" />
                  <span className="sr-only">Tukar bahasa</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>Bahasa</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>Bahasa Melayu</DropdownMenuItem>
                <DropdownMenuItem>中文</DropdownMenuItem>
                <DropdownMenuItem>தமிழ்</DropdownMenuItem>
                <DropdownMenuItem>ไทย</DropdownMenuItem>
                <DropdownMenuItem>Indonesia</DropdownMenuItem>
                <DropdownMenuItem>English</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {/* Notifications */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative h-10 w-10 sm:h-11 sm:w-11 btn-ghost-better">
                  <Bell className="h-5 w-5" />
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-6 w-6 sm:h-7 sm:w-7 rounded-full p-0 text-xs flex items-center justify-center font-bold"
                  >
                    3
                  </Badge>
                  <span className="sr-only">Notifikasi</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <DropdownMenuLabel>Notifikasi</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="flex-col items-start p-4">
                  <div className="font-medium">Sistem Maintenance</div>
                  <div className="text-sm text-muted-foreground mt-1">Sistem akan menjalani maintenance pada jam 2:00 PG</div>
                  <div className="text-xs text-muted-foreground mt-2">2 jam yang lalu</div>
                </DropdownMenuItem>
                <DropdownMenuItem className="flex-col items-start p-4">
                  <div className="font-medium">Data Baru Ditambah</div>
                  <div className="text-sm text-muted-foreground mt-1">3 rekod data tan sawit baru telah ditambah</div>
                  <div className="text-xs text-muted-foreground mt-2">5 jam yang lalu</div>
                </DropdownMenuItem>
                <DropdownMenuItem className="flex-col items-start p-4">
                  <div className="font-medium">Kemas Kini Lori</div>
                  <div className="text-sm text-muted-foreground mt-1">Maklumat lori telah dikemas kini</div>
                  <div className="text-xs text-muted-foreground mt-2">1 hari yang lalu</div>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-center justify-center text-blue-600">
                  Lihat Semua Notifikasi
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {/* Settings */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-10 w-10 sm:h-11 sm:w-11 btn-ghost-better">
                  <Settings className="h-5 w-5" />
                  <span className="sr-only">Tetapan</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuLabel>Tetapan Sistem</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSettingsClick}>
                  <Settings className="mr-2 h-4 w-4" />
                  Tetapan
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>
        </div>
      </div>
    </header>
  )
}