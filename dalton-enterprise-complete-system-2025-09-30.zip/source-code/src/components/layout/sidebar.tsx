"use client"

import React from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Home, Leaf, Truck, Users, Settings, Menu, X } from 'lucide-react'

interface NavigationItem {
  name: string
  href: string
  icon: React.ComponentType<any>
  page: string
}

const Sidebar = () => {
  const [isOpen, setIsOpen] = React.useState(false)
  const pathname = usePathname()

  const navigation: NavigationItem[] = [
    { name: "Papan Pemuka", href: "/", icon: Home, page: "dashboard" },
    { name: "Data Tan Sawit", href: "/palm-oil-data", icon: Leaf, page: "palm-oil-data" },
    { name: "Profile Lori", href: "/trucks", icon: Truck, page: "trucks" },
    { name: "Profile Pekerja", href: "/workers", icon: Users, page: "workers" },
    { name: "Tetapan", href: "/settings", icon: Settings, page: "settings" },
  ]

  const toggleMobile = () => {
    setIsOpen(!isOpen)
  }

  return (
    <React.Fragment>
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleMobile}
        className="fixed top-4 left-4 z-50 md:hidden h-9 w-9 btn-ghost-better"
      >
        <Menu className="h-4 w-4" />
      </Button>
      
      {isOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="fixed inset-0 bg-black/50" onClick={toggleMobile} />
          <div className="fixed left-0 top-0 h-full w-64 bg-sidebar border-r border-border shadow-sm enhanced-visibility">
            <div className="p-4 border-b">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-semibold">Dalton Enterprise</h2>
                </div>
                <Button variant="ghost" size="icon" onClick={toggleMobile} className="btn-ghost-better">
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <nav className="p-4 space-y-2">
              {navigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors sidebar-item ${
                      isActive ? "active" : ""
                    }`}
                    onClick={toggleMobile}
                  >
                    <item.icon className="h-4 w-4 text-sidebar-foreground" />
                    <span className="text-sidebar-foreground">{item.name}</span>
                  </Link>
                )
              })}
            </nav>
          </div>
        </div>
      )}
      
      <div className="hidden md:flex w-64 flex-col border-r border-border bg-sidebar shadow-sm enhanced-visibility">
        <div className="p-4 border-b">
          <div>
            <h2 className="font-semibold">Dalton Enterprise</h2>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          {navigation.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.name}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors sidebar-item ${
                  isActive ? "active" : ""
                }`}
              >
                <item.icon className="h-4 w-4 text-sidebar-foreground" />
                <span className="text-sidebar-foreground">{item.name}</span>
              </Link>
            )
          })}
        </nav>
      </div>
    </React.Fragment>
  )
}

export default Sidebar