"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { RealTimeClock } from "@/components/dashboard/real-time-clock"
import { StatisticsCard } from "@/components/dashboard/statistics-card"
import { DataFilters } from "@/components/dashboard/data-filters"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/lib/auth"
import { 
  Leaf, 
  DollarSign, 
  Truck, 
  TrendingUp,
  BarChart3,
  PieChart,
  RefreshCw,
  Download
} from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Cell,
  Pie
} from "recharts"

interface PalmOilData {
  id: string
  date: string
  blockCode: string
  ramp: string
  buyer: string
  name: string
  truckNo: string
  price: number
  weight: number
  total: number
}

interface FilterState {
  truckNo: string
  ramp: string
  startDate: Date | undefined
  endDate: Date | undefined
}

interface DashboardStats {
  totalTons: number
  totalPrice: number
  activeTrucks: number
  averagePrice: number
}

export default function Dashboard() {
  const router = useRouter()
  const { isAuthenticated, isLoading, user } = useAuth()
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [isClient, setIsClient] = useState(false)
  const [palmOilData, setPalmOilData] = useState<PalmOilData[]>([])
  const [currentFilters, setCurrentFilters] = useState<FilterState>({
    truckNo: "all",
    ramp: "all",
    startDate: undefined,
    endDate: undefined
  })
  const [stats, setStats] = useState<DashboardStats>({
    totalTons: 0,
    totalPrice: 0,
    activeTrucks: 0,
    averagePrice: 0
  })
  const [filteredStats, setFilteredStats] = useState<DashboardStats>({
    totalTons: 0,
    totalPrice: 0,
    activeTrucks: 0,
    averagePrice: 0
  })

  useEffect(() => {
    setIsClient(true)
    setDate(new Date())
    
    const fetchPalmOilData = async () => {
      try {
        const response = await fetch('/api/palm-oil-data')
        if (response.ok) {
          const data = await response.json()
          const formattedData = data.map((item: any) => ({
            id: item.id,
            date: item.date ? new Date(item.date).toISOString().split('T')[0] : '',
            blockCode: item.blockCode,
            ramp: item.ramp,
            buyer: item.buyer,
            name: item.name,
            truckNo: item.truckNo,
            price: item.price,
            weight: item.weight,
            total: item.total
          }))
          setPalmOilData(formattedData)
          console.log('Dashboard loaded data from API:', formattedData)
        } else {
          console.error('Failed to fetch palm oil data from API')
          setPalmOilData([])
        }
      } catch (error) {
        console.error('Error fetching palm oil data:', error)
        setPalmOilData([])
      }
    }
    
    // Only fetch data if authenticated
    if (isAuthenticated) {
      // Initial load
      fetchPalmOilData()
      
      // Set up periodic refresh (every 30 seconds)
      const interval = setInterval(fetchPalmOilData, 30000)
      
      // Cleanup
      return () => clearInterval(interval)
    }
  }, [isAuthenticated])

  // Calculate stats from actual data
  const calculateStats = (data: PalmOilData[]): DashboardStats => {
    if (data.length === 0) {
      return {
        totalTons: 0,
        totalPrice: 0,
        activeTrucks: 0,
        averagePrice: 0
      }
    }
    
    const totalTons = data.reduce((sum, item) => sum + item.weight, 0)
    const totalPrice = data.reduce((sum, item) => sum + item.total, 0)
    const uniqueTrucks = new Set(data.map(item => item.truckNo)).size
    const averagePrice = totalPrice / totalTons
    
    return {
      totalTons,
      totalPrice,
      activeTrucks: uniqueTrucks,
      averagePrice: averagePrice || 0
    }
  }

  useEffect(() => {
    // Calculate stats from actual data
    const calculatedStats = calculateStats(palmOilData)
    setStats(calculatedStats)
    setFilteredStats(calculatedStats)
    console.log('Dashboard stats calculated:', calculatedStats)
  }, [palmOilData])

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p>Memuatkan...</p>
        </div>
      </div>
    )
  }

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    router.push("/login")
    return null
  }

  const handleFilterChange = (filters: FilterState) => {
    console.log("Filters changed:", filters)
    
    // Update current filters state
    setCurrentFilters(filters)
    
    // Filter data based on filters
    let filteredData = palmOilData
    
    if (filters.truckNo !== "all") {
      filteredData = filteredData.filter(item => item.truckNo === filters.truckNo)
    }
    
    if (filters.ramp !== "all") {
      filteredData = filteredData.filter(item => item.ramp === filters.ramp)
    }
    
    if (filters.startDate) {
      const startDate = new Date(filters.startDate)
      filteredData = filteredData.filter(item => {
        const itemDate = new Date(item.date)
        return itemDate >= startDate
      })
    }
    
    if (filters.endDate) {
      const endDate = new Date(filters.endDate)
      filteredData = filteredData.filter(item => {
        const itemDate = new Date(item.date)
        return itemDate <= endDate
      })
    }
    
    // Calculate stats from filtered data
    const calculatedFilteredStats = calculateStats(filteredData)
    setFilteredStats(calculatedFilteredStats)
    console.log('Filtered stats calculated:', calculatedFilteredStats)
  }

  // Calculate daily statistics for chart
  const calculateDailyStats = () => {
    const dailyData: { [key: string]: { weight: number; total: number; count: number } } = {}
    
    palmOilData.forEach(item => {
      if (!dailyData[item.date]) {
        dailyData[item.date] = { weight: 0, total: 0, count: 0 }
      }
      dailyData[item.date].weight += item.weight
      dailyData[item.date].total += item.total
      dailyData[item.date].count += 1
    })
    
    return Object.entries(dailyData)
      .map(([date, data]) => ({
        date,
        weight: Number(data.weight.toFixed(2)),
        total: Number(data.total.toFixed(2)),
        averagePrice: data.weight > 0 ? Number((data.total / data.weight).toFixed(2)) : 0
      }))
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(-7) // Last 7 days
  }

  // Calculate truck distribution for pie chart
  const calculateTruckDistribution = () => {
    const truckData: { [key: string]: { weight: number; count: number } } = {}
    
    palmOilData.forEach(item => {
      if (!truckData[item.truckNo]) {
        truckData[item.truckNo] = { weight: 0, count: 0 }
      }
      truckData[item.truckNo].weight += item.weight
      truckData[item.truckNo].count += 1
    })
    
    return Object.entries(truckData)
      .map(([truckNo, data]) => ({
        name: truckNo,
        value: Number(data.weight.toFixed(2)),
        count: data.count
      }))
      .sort((a, b) => b.value - a.value)
  }

  const dailyStats = calculateDailyStats()
  const truckDistribution = calculateTruckDistribution()

  // Colors for pie chart
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658']

  // Function to refresh data manually
  const refreshData = async () => {
    try {
      const response = await fetch('/api/palm-oil-data')
      if (response.ok) {
        const data = await response.json()
        const formattedData = data.map((item: any) => ({
          id: item.id,
          date: item.date ? new Date(item.date).toISOString().split('T')[0] : '',
          blockCode: item.blockCode,
          ramp: item.ramp,
          buyer: item.buyer,
          name: item.name,
          truckNo: item.truckNo,
          price: item.price,
          weight: item.weight,
          total: item.total
        }))
        setPalmOilData(formattedData)
        console.log('Dashboard data refreshed:', formattedData)
      }
    } catch (error) {
      console.error('Error refreshing data:', error)
    }
  }

  // Function to get current filters for synchronization
  const getCurrentFilters = (): FilterState => {
    return currentFilters
  }

  // Function to get filtered data for export
  const getFilteredDataForExport = (): PalmOilData[] => {
    console.log("Getting filtered data for export. Current filters:", currentFilters)
    
    let filteredData = [...palmOilData] // Create a copy of the original data
    console.log("Original data length:", filteredData.length)
    
    // Apply truck filter
    if (currentFilters.truckNo && currentFilters.truckNo !== "all") {
      filteredData = filteredData.filter(item => item.truckNo === currentFilters.truckNo)
      console.log("After truck filter:", filteredData.length)
    }
    
    // Apply ramp filter
    if (currentFilters.ramp && currentFilters.ramp !== "all") {
      filteredData = filteredData.filter(item => item.ramp === currentFilters.ramp)
      console.log("After ramp filter:", filteredData.length)
    }
    
    // Apply start date filter
    if (currentFilters.startDate) {
      const startDate = new Date(currentFilters.startDate)
      startDate.setHours(0, 0, 0, 0) // Set to start of day
      filteredData = filteredData.filter(item => {
        const itemDate = new Date(item.date)
        return itemDate >= startDate
      })
      console.log("After startDate filter:", filteredData.length)
    }
    
    // Apply end date filter
    if (currentFilters.endDate) {
      const endDate = new Date(currentFilters.endDate)
      endDate.setHours(23, 59, 59, 999) // Set to end of day
      filteredData = filteredData.filter(item => {
        const itemDate = new Date(item.date)
        return itemDate <= endDate
      })
      console.log("After endDate filter:", filteredData.length)
    }
    
    console.log("Final filtered data length:", filteredData.length)
    console.log("Filtered data sample:", filteredData.slice(0, 2))
    
    return filteredData
  }

  const handleExport = async (format: 'excel' | 'pdf') => {
    console.log(`Exporting data as ${format}`)
    console.log("Current filters state:", currentFilters)
    console.log("Total palmOilData length:", palmOilData.length)
    
    try {
      // Check if we have data
      if (!palmOilData || palmOilData.length === 0) {
        alert('Tiada data tersedia untuk dieksport.')
        return
      }
      
      // Get filtered data for export
      const exportData = getFilteredDataForExport()
      const isFiltered = exportData.length !== palmOilData.length
      
      console.log("Export data length:", exportData.length)
      console.log("Is filtered:", isFiltered)
      
      if (exportData.length === 0) {
        alert('Tiada data untuk dieksport selepas penapisan. Sila cuba penapis yang berbeza atau kosongkan penapis.')
        return
      }
      
      // Validate export data
      if (!Array.isArray(exportData)) {
        throw new Error('Export data is not an array')
      }
      
      if (format === 'excel') {
        try {
          console.log("Starting Excel export...")
          
          // Dynamic import XLSX
          const XLSX = await import('xlsx')
          console.log("XLSX imported successfully")
          
          // Validate XLSX functions
          if (!XLSX.utils || !XLSX.utils.json_to_sheet) {
            throw new Error('XLSX.utils not available')
          }
          
          // Prepare data for Excel
          const excelData = exportData.map(item => ({
            'Tarikh': item.date || '',
            'Kod Block': item.blockCode || '',
            'Ramp': item.ramp || '',
            'Pembeli': item.buyer || '',
            'Nama': item.name || '',
            'No Lori': item.truckNo || '',
            'Harga (RM)': Number(item.price) || 0,
            'Berat (tan)': Number(item.weight) || 0,
            'Jumlah (RM)': Number(item.total) || 0
          }))
          
          console.log("Excel data prepared:", excelData.length, "rows")
          
          // Create worksheet
          const ws = XLSX.utils.json_to_sheet(excelData)
          console.log("Worksheet created")
          
          // Create workbook
          const wb = XLSX.utils.book_new()
          const sheetName = isFiltered ? "Data Tan Sawit (Terfilter)" : "Data Tan Sawit Dashboard"
          XLSX.utils.book_append_sheet(wb, ws, sheetName)
          console.log("Workbook created")
          
          // Generate filename
          const fileName = isFiltered 
            ? `dashboard_tan_sawit_terfilter_${new Date().toISOString().split('T')[0]}.xlsx`
            : `dashboard_tan_sawit_${new Date().toISOString().split('T')[0]}.xlsx`
          
          // Check if XLSX.writeFile is available
          if (typeof XLSX.writeFile !== 'function') {
            throw new Error('XLSX.writeFile is not available')
          }
          
          // Write file
          XLSX.writeFile(wb, fileName)
          
          console.log(`Excel file exported: ${fileName}`)
          console.log(`Data points exported: ${exportData.length}`)
          alert(`Berjaya mengeksport ${exportData.length} rekod ke ${fileName}`)
        } catch (excelError) {
          console.error('Excel export error:', excelError)
          console.error('Error details:', excelError.message)
          alert('Ralat semasa mengeksport ke Excel. Sila cuba lagi.')
        }
      } else if (format === 'pdf') {
        try {
          console.log("Starting PDF export...")
          
          // Dynamic import jsPDF
          const jsPDFModule = await import('jspdf')
          const jsPDF = jsPDFModule.default || jsPDFModule
          console.log("jsPDF imported successfully")
          
          // Check if jsPDF is available
          if (typeof jsPDF !== 'function') {
            throw new Error('jsPDF is not available')
          }
          
          const pdf = new jsPDF()
          console.log("PDF instance created")
          
          // Add title
          pdf.setFontSize(20)
          const title = isFiltered ? 'Laporan Dashboard Tan Sawit (Terfilter)' : 'Laporan Dashboard Tan Sawit'
          pdf.text(title, 20, 20)
          
          // Add date
          pdf.setFontSize(12)
          pdf.text(`Tarikh: ${new Date().toLocaleDateString('ms-MY')}`, 20, 35)
          
          // Add statistics
          pdf.setFontSize(14)
          pdf.text('Statistik Keseluruhan:', 20, 50)
          pdf.setFontSize(10)
          pdf.text(`Jumlah Tan: ${stats.totalTons.toFixed(2)} tan`, 20, 60)
          pdf.text(`Jumlah Harga: RM ${stats.totalPrice.toFixed(2)}`, 20, 70)
          pdf.text(`Lori Aktif: ${stats.activeTrucks}`, 20, 80)
          pdf.text(`Purata Harga: RM ${stats.averagePrice.toFixed(2)}`, 20, 90)
          
          // Add filtered statistics if different from overall
          if (isFiltered) {
            pdf.setFontSize(14)
            pdf.text('Statistik Terfilter:', 20, 110)
            pdf.setFontSize(10)
            pdf.text(`Jumlah Tan (Terfilter): ${filteredStats.totalTons.toFixed(2)} tan`, 20, 120)
            pdf.text(`Jumlah Harga (Terfilter): RM ${filteredStats.totalPrice.toFixed(2)}`, 20, 130)
            pdf.text(`Lori Aktif (Terfilter): ${filteredStats.activeTrucks}`, 20, 140)
            pdf.text(`Purata Harga (Terfilter): RM ${filteredStats.averagePrice.toFixed(2)}`, 20, 150)
          }
          
          // Add data table
          if (exportData.length > 0) {
            pdf.setFontSize(14)
            pdf.text('Data Terperinci:', 20, isFiltered ? 170 : 120)
            
            // Simple table
            let yPosition = isFiltered ? 180 : 130
            pdf.setFontSize(8)
            
            // Table headers
            pdf.text('Tarikh', 20, yPosition)
            pdf.text('Block', 40, yPosition)
            pdf.text('Ramp', 60, yPosition)
            pdf.text('Lori', 80, yPosition)
            pdf.text('Berat', 100, yPosition)
            pdf.text('Harga', 120, yPosition)
            pdf.text('Jumlah', 140, yPosition)
            
            yPosition += 10
            
            // Table data (limit to first 20 items to fit on page)
            const displayData = exportData.slice(0, 20)
            displayData.forEach((item, index) => {
              if (yPosition > 270) {
                pdf.addPage()
                yPosition = 20
              }
              
              pdf.text(item.date || '', 20, yPosition)
              pdf.text(item.blockCode || '', 40, yPosition)
              pdf.text(item.ramp || '', 60, yPosition)
              pdf.text(item.truckNo || '', 80, yPosition)
              pdf.text((item.weight || 0).toString(), 100, yPosition)
              pdf.text((item.price || 0).toString(), 120, yPosition)
              pdf.text((item.total || 0).toString(), 140, yPosition)
              
              yPosition += 8
            })
            
            // Add note if there are more items
            if (exportData.length > 20) {
              pdf.text(`... dan ${exportData.length - 20} lagi rekod`, 20, yPosition + 10)
            }
          }
          
          const fileName = isFiltered 
            ? `dashboard_tan_sawit_terfilter_${new Date().toISOString().split('T')[0]}.pdf`
            : `dashboard_tan_sawit_${new Date().toISOString().split('T')[0]}.pdf`
          
          // Check if pdf.save is available
          if (typeof pdf.save !== 'function') {
            throw new Error('pdf.save is not available')
          }
          
          pdf.save(fileName)
          
          console.log(`PDF file exported: ${fileName}`)
          console.log(`Data points exported: ${exportData.length}`)
          alert(`Berjaya mengeksport ${exportData.length} rekod ke ${fileName}`)
        } catch (pdfError) {
          console.error('PDF export error:', pdfError)
          console.error('Error details:', pdfError.message)
          alert('Ralat semasa mengeksport ke PDF. Sila cuba lagi.')
        }
      }
    } catch (error) {
      console.error('General export error:', error)
      console.error('Error details:', error.message)
      alert('Ralat semasa mengeksport data. Sila cuba lagi.')
    }
  }

  const displayStats = filteredStats.totalTons > 0 ? filteredStats : stats

  return (
    <div className="space-y-4 sm:space-y-6">
        <div className="px-2 sm:px-0">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Papan Pemuka</h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Gambaran keseluruhan operasi tanaman sawit anda
          </p>
        </div>

      <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <RealTimeClock />
        
        <Card className="sm:col-span-2 lg:col-span-3">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kalendar</CardTitle>
          </CardHeader>
          <CardContent className="p-0 sm:p-0">
            {isClient && date ? (
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                className="rounded-md border"
              />
            ) : (
              <div className="h-48 sm:h-64 flex items-center justify-center text-muted-foreground">
                Memuatkan kalendar...
              </div>
            )}
          </CardContent>
        </Card>
      </div>

        <DataFilters 
          onFilterChange={handleFilterChange}
          onExport={handleExport}
          currentFilters={currentFilters}
        />

      <div className="grid gap-4 sm:gap-6 grid-cols-2 lg:grid-cols-4">
        <StatisticsCard
          title="Jumlah Tan"
          value={displayStats.totalTons.toFixed(2)}
          description="Jumlah keseluruhan tan"
          icon={Leaf}
          trend={{ value: 12, isPositive: true }}
        />
        <StatisticsCard
          title="Jumlah Harga"
          value={`RM ${displayStats.totalPrice.toFixed(2)}`}
          description="Jumlah keseluruhan harga"
          icon={DollarSign}
          trend={{ value: 8, isPositive: true }}
        />
        <StatisticsCard
          title="Lori Aktif"
          value={displayStats.activeTrucks}
          description="Bilangan lori aktif"
          icon={Truck}
          trend={{ value: 2, isPositive: true }}
        />
        <StatisticsCard
          title="Purata Harga"
          value={`RM ${displayStats.averagePrice.toFixed(2)}`}
          description="Harga purata per tan"
          icon={TrendingUp}
          trend={{ value: -3, isPositive: false }}
        />
      </div>

      <div className="grid gap-4 sm:gap-6 grid-cols-1 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Statistik Harian
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={refreshData}
                className="h-8 w-8"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {dailyStats.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={dailyStats}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip 
                    formatter={(value, name) => [
                      name === 'weight' ? `${value} tan` : `RM ${value}`,
                      name === 'weight' ? 'Berat' : name === 'total' ? 'Jumlah' : 'Harga Purata'
                    ]}
                    labelFormatter={(label) => `Tarikh: ${label}`}
                  />
                  <Legend />
                  <Bar dataKey="weight" fill="#8884d8" name="Berat (tan)" />
                  <Bar dataKey="total" fill="#82ca9d" name="Jumlah (RM)" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-48 sm:h-64 flex items-center justify-center text-muted-foreground">
                Tiada data tersedia untuk carta statistik harian
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="h-4 w-4" />
              Pengagihan Lori
            </CardTitle>
          </CardHeader>
          <CardContent>
            {truckDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <RechartsPieChart>
                  <Pie
                    data={truckDistribution}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {truckDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value, name) => [
                      `${value} tan`,
                      'Jumlah Berat'
                    ]}
                  />
                </RechartsPieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-48 sm:h-64 flex items-center justify-center text-muted-foreground">
                Tiada data tersedia untuk carta pengagihan lori
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      </div>
  )
}