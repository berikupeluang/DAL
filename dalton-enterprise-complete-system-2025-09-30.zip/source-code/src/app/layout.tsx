import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import Sidebar from "@/components/layout/sidebar";
import { Header } from "@/components/layout/header";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Dalton Enterprise - Sistem Pengurusan Tanaman Sawit",
  description: "Sistem pengurusan komprehensif untuk perusahaan tanaman sawit dengan ciri-ciri moden dan responsif.",
  keywords: ["Dalton Enterprise", "Tanaman Sawit", "Pengurusan", "Next.js", "TypeScript"],
  authors: [{ name: "Dalton Enterprise Team" }],
  openGraph: {
    title: "Dalton Enterprise",
    description: "Sistem pengurusan komprehensif untuk perusahaan tanaman sawit",
    url: "https://dalton-enterprise.com",
    siteName: "Dalton Enterprise",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Dalton Enterprise",
    description: "Sistem pengurusan komprehensif untuk perusahaan tanaman sawit",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ms" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <script
          dangerouslySetInnerHTML={{
            __html: `
              // Initialize theme if not exists
              if (typeof localStorage !== 'undefined' && !localStorage.getItem('dalton-theme')) {
                // Check system preference
                if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                  localStorage.setItem('dalton-theme', 'dark');
                } else {
                  localStorage.setItem('dalton-theme', 'light');
                }
              }
            `,
          }}
        />
        <Providers>
          <div className="flex h-screen bg-background enhanced-visibility">
            <Sidebar />
            <div className="flex-1 flex flex-col overflow-hidden">
              <Header />
              <main className="flex-1 overflow-y-auto bg-background enhanced-visibility">
                <div className="container mx-auto p-3 sm:p-4 md:p-6 lg:p-8">
                  {children}
                </div>
              </main>
            </div>
          </div>
          <Toaster />
        </Providers>
      </body>
    </html>
  );
}
