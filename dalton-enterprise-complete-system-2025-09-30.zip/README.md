# Dalton Enterprise Palm Oil Management System

## Complete System Export

This ZIP file contains a complete export of the Dalton Enterprise Palm Oil Management System.

## Contents

- `system-info.json` - System information and metadata
- `settings/` - System settings and configuration
- `database/` - Database files and exported data
- `source-code/` - Key source code files

## Setup Instructions

1. Extract the ZIP file to your desired location
2. Install dependencies: `npm install`
3. Set up the database: `npm run db:push`
4. Start the development server: `npm run dev`
5. Open http://localhost:3000 in your browser

## Database Setup

If you have the database file (`database/custom.db`), place it in the `db/` directory of your project.

## Import Data

To import the exported data, you can use the JSON files in the `database/` directory with your database management tools.

## System Requirements

- Node.js 18+ 
- npm or yarn
- SQLite (included with Prisma)

## Support

For support and questions, please refer to the original system documentation.

---
Exported on: 2025-09-30T08:01:12.149Z
System Version: 1.0.0
